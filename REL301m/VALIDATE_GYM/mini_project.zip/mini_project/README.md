1. If you want to run the test, please change the pkl file to the pretrain pkl absolute path.

2. If not try install environment follow step below:
step to run:
- cd custome_game
- pip install -e .

3. Train the model and try again