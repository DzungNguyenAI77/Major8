import numpy as np 
from sklearn.tree import DecisionTreeClassifier

class Gridworld:
    def __init__(self):
        self.grid_size = (3, 3)
        self.num_actions = 4  # Up, Down, Left, Right
        self.start_state = (0, 0)
        self.goal_state = (2, 2)

    def step(self, state, action):
        # Define the dynamics of the environment
        row, col = state
        if action == 0:  # Up
            row = max(0, row - 1)
        elif action == 1:  # Down
            row = min(self.grid_size[0] - 1, row + 1)
        elif action == 2:  # Left
            col = max(0, col - 1)
        elif action == 3:  # Right
            col = min(self.grid_size[1] - 1, col + 1)
        next_state = (row, col)
        reward = 0
        if next_state == self.goal_state:
            reward = 1  # reward of +1 upon reaching the goal state
        return next_state, reward

    def generate_training_data(self, num_samples):
        X = np.zeros((num_samples, 2))  # State features
        Y = np.zeros((num_samples,))  # Actions
        for i in range(num_samples):
            state = (np.random.randint(self.grid_size[0]),
                     np.random.randint(self.grid_size[1]))
            action = np.random.randint(self.num_actions)
            next_state, _ = self.step(state, action)
            X[i] = state
            Y[i] = action
        return X, Y

# Create a grid world environment
grid_world = Gridworld()

# Generate training data
num_samples = 1000
X_train, y_train = grid_world.generate_training_data(num_samples)

# Train a supervised learning model using Decision Tree Classifier
model = DecisionTreeClassifier()
model.fit(X_train, y_train)  # Training the model

# Evaluate the learned policy, return total reward
def evaluate_policy(grid_world, model):
    state = grid_world.start_state
    total_reward = 0
    
    # Simulate the policy until the goal state is reached
    while state != grid_world.goal_state:
        state_features = np.array(state).reshape(1, -1)  # Reshape for model input
        action = model.predict(state_features)[0]  # Predict action using the model
        next_state, reward = grid_world.step(state, action)  # Take the action
        total_reward += reward  # Accumulate the reward
        state = next_state  # Update the state

    return total_reward

# Evaluate the learned policy
total_reward = evaluate_policy(grid_world, model)
print("Total reward obtained by learned policy:", total_reward)
